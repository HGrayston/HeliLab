%% Oppgave 1
% Define your continuous-time system matrices (A, B, C)
K_3 = 3;
K_2 = 2;
K_1 = 1;
% Replace the following placeholders with your specific matrix values
% Define your A matrix
A = [0 1 0 0 0 0;
    0 0 0 0 0 0; 
    0 0 0 1 0 0; 
    0 0 0 0 0 0; 
    0 0 0 0 0 1; 
    K_3 0 0 0 0 0];  

% Define your B matrix
B = [0 0; 0 K_1; 0 0;K_2 0; 0 0; 0 0];
% Define your C matrix
C = eye(6); 

% Set the sampling time
Ts = 0.002;  % 0.002 seconds (Simulink time step)

% Use c2d to discretize only the system matrices
sys_d = c2d(ss(A, B, C, 0), Ts, 'zoh');

% Extract the discrete-time system matrices
Ad = sys_d.A;
Bd = sys_d.B;
Cd = sys_d.C;

% Display the discrete-time matrices
disp('Discrete-time system matrices:');
disp('Ad = ');
disp(Ad);
disp('Bd = ');
disp(Bd);
disp('Cd = ');
disp(Cd);



%% Oppgave 2
% Hypotheses:
% 
% State Estimation Precision: The choice of Qd values along
% the diagonal will affect the precision of state estimation. Larger values
% on the diagonal will introduce more uncertainty in the state estimates,
% while smaller values will make the estimates more precise.
% 
% Impact on Noisy States: States that are more affected
% by measurement noise (e.g., states with a lower signal-to-noise ratio) may
% benefit from larger Qd values. Conversely, states with high
% signal-to-noise ratios may require smaller Qd values.
% 
% Stability and Control: An extremely small Qd value
% (close to zero) may lead to an overly confident filter that might be
% sensitive to noise and might lead to instability in the control system.
% Conversely, an extremely large Qd value might make the filter overly
% conservative, resulting in sluggish control.
% 
% Computational Resources: The choice of Qd affects the computational
% resources required for Kalman filtering. Very large Qd values may lead to
% increased computational load, while very small Qd values may not make
% efficient use of computational resources.__
% 
% Test Plan:
% 
% To test these hypotheses, you can create a test plan with a range of Qd
% values to be carried out during your lab time-slot. Ensure that the
% values cover a broad spectrum, including values close to 0 and very large
% values (approaching infinity).
% 
% For example, you can set up a series of experiments with different Qd
% values along the diagonal, varying from very small values to very large
% values. Here is a simplified test plan:
% 
% Set Qd to a very small value (e.g., 1e-6) for all diagonal elements.
% Set Qd to a moderate small value (e.g., 0.01) for all diagonal elements.
% Set Qd to a moderate value (e.g., 1.0) for all diagonal elements.
% Set Qd to a larger value (e.g., 10.0) for all diagonal elements.
% Set Qd to a very large value (e.g., 1e6) for all diagonal elements.
% During each experiment, observe how the state estimation changes, including wprecision and stability. Note any issues with convergence, control performance, or computational load.
% 
% By conducting these experiments, you can gain insights into how the choice of Qd values 
% affects the state estimation in your specific system and determine the best value for your 
% particular application._

%% Bonus oppgave
% Define the number of state variables (dimension of x)
%n = size(Ad, 1);

% Define the process noise covariance matrix in continuous-time Qc
%Qc = ... % Define your continuous-time process noise covariance matrix

% Sample time (Ts)
%Ts = ... % Define your sampling time

% Calculate Qd using the discretized process noise covariance matrix Qc
%Qd = Ad * Qc * Ad' * Ts; % Discretization
