% FOR HELICOPTER NR 3-10
% This file contains the initialization for the helicopter assignment in
% the course TTK4115. Run this file before you execute QuaRC_ -> Build 
% to build the file heli_q8.mdl.

% Oppdatert h�sten 2006 av Jostein Bakkeheim
% Oppdatert h�sten 2008 av Arnfinn Aas Eielsen
% Oppdatert h�sten 2009 av Jonathan Ronen
% Updated fall 2010, Dominik Breu
% Updated fall 2013, Mark Haring
% Updated spring 2015, Mark Haring


%%%%%%%%%%% Calibration of the encoder and the hardware for the specific
%%%%%%%%%%% helicopter
Joystick_gain_x = 1;
Joystick_gain_y = - 1;
PORT = 4;
%r�d er X
%bl� er y
%gul er Z
V_s0 = 7.5;
%V_s0 = 7.5;
%%%%%%%%%%% Physical constants
g = 9.81; % gravitational constant [m/s^2]
l_c = 0.46; % distance elevation axis to counterweight [m]
l_h = 0.66; % distance elevation axis to helicopter head [m]
l_p = 0.175; % distance pitch axis to motor [m]
m_c = 1.92; % Counterweight mass [kg]
m_p = 0.72; % Motor mass [kg]

%dag 1

K_1= (K_f)/(2*m_p*l_p);
K_2 = (l_h*K_f)/(m_c*(l_c).^2+2*m_p*(l_h).^2);
K_3 = (l_h*K_f)/(m_c*(l_c).^2+2*m_p*((l_h).^2+(l_p).^2));
K_f2 = -g * (m_c*l_c - 2*m_p*l_h) / (l_h * V_s0); 
K_f = 0.0136;

eig_1 = -1;
eig_2 = -1;

K_pp = (eig_1*eig_2)/K_1;
K_pd = -(eig_1+eig_2)/K_1;




%dag 2

%Fra task 1:
%uten integraleffekt
A_i = [0 1 0; 0 0 0; 0 0 0];
B_i = [0 0;0 K_1;K_2 0];

Q = [10 0 0;
    0 10 0;
    0 0 10]';

R = [1 0;
    0 1];


K = lqr(A_i,B_i,Q,R);
F = [K(1,1),K(1,3);K(2,1),K(2,3)];
C_i = eye(5);

%med integraleffekt
A_i2 = [0 1 0 0 0;
    0 0 0 0 0;
    0 0 0 0 0;
    -1 0 0 0 0;
    0 0 -1 0 0];

B_i2 = [0 0;
    0 K_1;
    K_2 0;
    0 0;
    0 0];

C_i2 = eye(5);

Q_i2 = diag([1 1 1 1 1]);

R_i2 = [0.5 0;
    0 1];


K_i2 = lqr(A_i2,B_i2,Q_i2,R_i2);
F_i2 = [K_i2(1,1),K_i2(1,3);K_i2(2,1),K_i2(2,3)];


%DAG 3 LUENBERGER

A_est = [0 1 0 0 0;
         0 0 0 0 0;
         0 0 0 1 0;
         0 0 0 0 0;
         K_3 0 0 0 0];
 
B_est = [0 0;
         0 K_1;
         0 0;
         K_2 0;
         0 0];

%I dokumentet
% C_est = diag([1 1 1 1 1]);
% C1 = diag([0 1 1 1 1]);
% C2 = diag([1 1 1 0 1]);
% C3 = diag([1 1 0 0 1]);
C_est = diag([1 1 1 0 0]);

Q_est = diag([1 1 1 1 1]);

R_est = [1 0;
        0 1];
    
K_est = lqr(A_est, B_est, Q_est, R_est);

%system_poles = eig(A_est-B_est*K_est);

system_poles = [-1 -2 -3 -4 -5];

L = place(A_est', C_est', system_poles*100).';



%DAG 4 KALMAN FILTER
%m�ling 5
%tilstand 6

% Replace the following placeholders with your specific matrix values
% Define your A matrix
A = [0 1 0 0 0 0;
    0 0 0 0 0 0;
    0 0 0 1 0 0;
    0 0 0 0 0 0;
    0 0 0 0 0 1;
    K_3 0 0 0 0 0];
B = [0 0; 0 K_1; 0 0;K_2 0; 0 0;0 0];


C = [1 0 0 0 0 0;
    0 1 0 0 0 0;
    0 0 1 0 0 0;
    0 0 0 1 0 0;
    0 0 0 0 0 1];

Ts = 0.002; 


sys_d = c2d(ss((A), (B), (C), 0), Ts, 'zoh');

Ad = sys_d.A;
Bd = sys_d.B;
Cd = sys_d.C;
Qd = 3e-5*eye(6);

Cov_fly = cov(MYGGO_fly);
Cov_chillin = cov(MYGGO_chillin);


%Rd = cov(Rd_raw(750:1500, 1:5));




% PLOTS AND GETTING VERDIER WRKSPACE
% MYGGO CHILL = MED SLAG
% MYGGO CHILLING = UTEN HANS-IMPULS RESPONS
%MYGGO_chill = MYGGO;
%MYGGO_fly = MYGGO(325:649,1:6);
%MYGGO_chillin = MYGGO_chill(1500:3389, 1:6);






% % Plotting MYGGO_chillin
% figure;
% 
% subplot(2, 1, 1); % 2 rows, 1 column, and this is the first subplot
% plot(MYGGO_chillin);
% legend('t', 't rate', 'p', 'p rate', 'e', 'e rate');
% title('Plotting states of MYGGO\_chillin');
% xlabel('time');
% ylabel('value');
% grid on;
% 
% % Plotting MYGGO_fly
% subplot(2, 1, 2); % 2 rows, 1 column, and this is the second subplot
% plot(MYGGO_fly);
% legend('t', 't rate', 'p', 'p rate', 'e', 'e rate');
% title('Plotting states of MYGGO\_fly');
% xlabel('time');
% ylabel('value');
% grid on;
% %P_cov_fly = cov(MYGGO);
% %P_cov_chillin  = cov(MYGGO);

% Plot the covariance matrices


